@extends('negocioMO/layout/layout')
@section('contenido')

    <section class="ftco-fixed clearfix">
        <div class="image js-fullheight float-left">
            <div class="home-slider owl-carousel js-fullheight">
                @if(!empty($tienda))
                    <div class="slider-item js-fullheight" style="background-image: url({{asset($tienda->imagen)}});">
                @elseif(!empty($farmacia))
                    <div class="slider-item js-fullheight" style="background-image: url({{asset($farmacia->imagen)}});">
                @elseif(!empty($hospital))
                    <div class="slider-item js-fullheight" style="background-image: url({{asset($hospital->imagen)}});">
                @endif
                                <div class="overlay"></div>
                                <div class="container">
                                    <div class="row slider-text align-items-end" data-scrollax-parent="true">
                                        <div class="col-md-10 col-sm-12 ftco-animate"
                                             data-scrollax=" properties: { translateY: '70%' }">
                                            <!--<p class="breadcrumbs"><span><a href="index.blade.php">Home</a></span> <span>Contact</span></p>-->
                                            <!--<h1 class="mb-3" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Ficha de Detalle</h1>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div>
            </div><!-- end:image -->
            <div class="page-container contact-section float-right">
                <div class="row d-flex mb-5 contact-info">
                    <div class="col-md-12 mb-4">
                        <h2 class="h4">Ficha de Detalle</h2>
                    </div>

                    @if(!empty($farmacia))
                        <div class="col-md-12">
                            <p><span>Horario:</span> 9:00 - 21:00</p>
                        </div>
                        <div class="col-md-12">
                            <p><span>Responsable:</span> Dra. Ma Carolina Dominguez R.</p>
                        </div>
                        <div class="col-md-12">
                            <p><span>REG. S.S.A. 77541</span> CED. PROF. 614344</p>
                        </div>
                        <div class="col-md-12">
                            <p><span>Direccion: </span> Av. Francisco I. Madero y Juan de Dios Peza s/n</p>
                        </div>
                    @endif


                </div>
                <div class="row block-9">
                    <div class="col-md-12 mb-5">
                        @if(!empty($hospital))
                            <h2>Visita nuestra pagina web <a href="{{route('hospital_index.index')}}" class="btn btn-danger text-right">Haz click aqui</a></h2>

                        @endif
                        <!--<form action="#">
                          <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Name">
                          </div>
                          <div class="form-group">
                            <input type="text" class="form-control" placeholder="Your Email">
                          </div>
                          <div class="form-group">
                            <input type="text" class="form-control" placeholder="Subject">
                          </div>
                          <div class="form-group">
                            <textarea name="" id="" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                          </div>
                          <div class="form-group">
                            <input type="submit" value="Send Message" class="btn btn-primary py-3 px-5">
                          </div>
                        </form>-->

                    </div>
                    <!-- <div class="col-md-12" id="map"></div>-->
                    <div class="embed-responsive embed-responsive-16by9">
                        <!-- <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d332.0261252927713!2d-99.1473481823613!3d19.69359322171353!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1f5203f5a2773%3A0xc0e204c3459a6955!2sTienda+La+VENTANITA!5e0!3m2!1ses!2smx!4v1545610342609" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> -->
                        @if(!empty($tienda))
                            <iframe class="embed-responsive-item" src="{{$tienda->maps}}" width="600" height="450"
                                    frameborder="0" style="border:0" allowfullscreen></iframe>
                        @elseif(!empty($farmacia))
                            <iframe class="embed-responsive-item" src="{{$farmacia->maps}}" width="600" height="450"
                                    frameborder="0" style="border:0" allowfullscreen></iframe>
                        @elseif(!empty($hospital))
                            <iframe class="embed-responsive-item" src="{{$hospital->maps}}" width="600" height="450"
                                    frameborder="0" style="border:0" allowfullscreen></iframe>
                        @endif
                    </div>
                </div>
            </div><!-- end: page-container-->
    </section>

    <!-- loader -->
    <div id="ftco-loader" class="show fullscreen">
        <svg class="circular" width="48px" height="48px">
            <circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/>
            <circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
                    stroke="#F96D00"/>
        </svg>
    </div>
@endsection